var app = angular.module('frank.controllers.friends', []);

app.controller('FriendsController', function($scope) {

  
});
