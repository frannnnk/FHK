var app = angular.module('frank.controllers.podcast', []);

app.controller('PodcastController', function($scope) {

  
});
