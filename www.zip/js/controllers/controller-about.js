var app = angular.module('frank.controllers.about', []);

app.controller('AboutController', function($scope) {

  
});
